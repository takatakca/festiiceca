//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BiCPxgRz.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Applications/Desktop/festiiceca/src/routes/__root.tsx",
		children: ["/", "/billets"],
		preloads: [
			"/assets/index-BvtHJCd3.js",
			"/assets/jsx-runtime-BkSabwWG.js",
			"/assets/preload-helper-D5qHF3Yi.js",
			"/assets/routes-CtKK4V-F.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BvtHJCd3.js"
		} }]
	},
	"/": {
		filePath: "/Applications/Desktop/festiiceca/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CQn_hfHp.js",
			"/assets/plus-BgJ9hgTf.js",
			"/assets/routes-CZGydb54.js",
			"/assets/routes-DPIkck-a.js"
		]
	},
	"/billets": {
		filePath: "/Applications/Desktop/festiiceca/src/routes/billets.tsx",
		children: void 0,
		preloads: ["/assets/billets-eVhLMxRq.js", "/assets/plus-BgJ9hgTf.js"]
	}
} });
//#endregion
export { tsrStartManifest };
