import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BYk9W4iE.js
var import_jsx_runtime = require_jsx_runtime();
var SplitNotFoundComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
	className: "mx-auto max-w-2xl px-4 py-32",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "text-3xl",
		children: "Page introuvable"
	})
});
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
