import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-CIHAFgYl.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-Y8M2SLMj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BoZwAqI3.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/**
* Public, read-only site content served from Lovable Cloud.
*
* Shapes intentionally mirror `@/lib/festi-data` so the UI can consume either
* source. Static data stays as the fallback when the backend has no content.
*/
var getSiteContent = createServerFn({ method: "GET" }).handler(createSsrRpc("5628aaee3be8917371cf667f0fa9e02784073998033f9f5baa65a4e0d019656a"));
var $$splitComponentImporter = () => import("./routes-j4xRclYI.mjs");
var $$splitNotFoundComponentImporter = () => import("./routes-BYk9W4iE.mjs");
var $$splitErrorComponentImporter = () => import("./routes-D4N1S6my.mjs");
var Route = createFileRoute("/")({
	loader: () => getSiteContent(),
	head: () => ({ meta: [
		{ title: "FESTI-ICE — Patinez dans la lumière | Maricourt, Québec" },
		{
			name: "description",
			content: "Patinage extérieur illuminé au Havana Resort de Maricourt : 263 acres, un parcours continu, une musique différente chaque soirée. Activité d'hiver familiale dans les Cantons-de-l'Est."
		},
		{
			property: "og:title",
			content: "FESTI-ICE — Patinez dans la lumière"
		},
		{
			property: "og:description",
			content: "Un parcours sur glace illuminé au cœur du Havana Resort. Une seule expérience, jamais la même ambiance."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
