import { r as __toESM } from "../_runtime.mjs";
import { d as ticketTypes, f as timeSlots, i as formatCents, o as programs, p as venue, r as flexOption, u as taxes } from "./festi-data-xAMTw4eE.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { t as Route } from "./billets-DTngiR73.mjs";
import { _ as Check, c as Plus, o as ShieldCheck, r as Ticket, u as Minus, v as ArrowLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billets-DC4jm1tI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MONTHS = [
	"janvier",
	"février",
	"mars",
	"avril",
	"mai",
	"juin",
	"juillet",
	"août",
	"septembre",
	"octobre",
	"novembre",
	"décembre"
];
var DAY_LETTERS = [
	"L",
	"M",
	"M",
	"J",
	"V",
	"S",
	"D"
];
/** ISO weekday 1..7 (Mon..Sun) */
function isoDay(d) {
	return d.getDay() === 0 ? 7 : d.getDay();
}
function toKey(d) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function programForDate(d) {
	return programs.find((p) => p.dayIndex === isoDay(d));
}
function BilletsPage() {
	const search = Route.useSearch();
	const [cursor, setCursor] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const [dateKey, setDateKey] = (0, import_react.useState)(search.date);
	const [slot, setSlot] = (0, import_react.useState)(void 0);
	const [quantities, setQuantities] = (0, import_react.useState)({});
	const [flex, setFlex] = (0, import_react.useState)(false);
	const [promo, setPromo] = (0, import_react.useState)("");
	const [step, setStep] = (0, import_react.useState)(search.date ? 2 : 1);
	const [placed, setPlaced] = (0, import_react.useState)(false);
	const selectedDate = dateKey ? /* @__PURE__ */ new Date(`${dateKey}T12:00:00`) : void 0;
	const program = selectedDate ? programForDate(selectedDate) : void 0;
	const lines = (0, import_react.useMemo)(() => ticketTypes.filter((t) => (quantities[t.id] ?? 0) > 0).map((t) => ({
		type: t,
		qty: quantities[t.id] ?? 0
	})), [quantities]);
	const totalTickets = lines.reduce((n, l) => n + l.qty, 0);
	const subtotal = lines.reduce((n, l) => n + l.qty * l.type.priceCents, 0);
	const flexTotal = flex ? totalTickets * flexOption.priceCents : 0;
	const taxable = subtotal + flexTotal;
	const taxLines = taxes.map((t) => ({
		code: t.code,
		cents: Math.round(taxable * t.rate)
	}));
	const total = taxable + taxLines.reduce((n, t) => n + t.cents, 0);
	const errors = [];
	const familyQty = quantities["tt-family"] ?? 0;
	if (familyQty > 0 && familyQty < 3) errors.push("La passe familiale exige un minimum de 3 billets.");
	if (familyQty > 6) errors.push("La passe familiale est limitée à 6 billets.");
	const adultsWithFamily = ticketTypes.filter((t) => t.countsAsAdult).reduce((n, t) => n + (quantities[t.id] ?? 0), 0);
	if (familyQty > 0 && adultsWithFamily > 2) errors.push("La passe familiale permet un maximum de 2 adultes.");
	const groupQty = quantities["tt-group"] ?? 0;
	if (groupQty > 0 && groupQty < 15) errors.push("Le tarif de groupe s'applique à partir de 15 personnes.");
	const canContinueTickets = totalTickets > 0 && errors.length === 0;
	const setQty = (id, delta) => setQuantities((q) => {
		const type = ticketTypes.find((t) => t.id === id);
		const next = Math.max(0, Math.min(type.maximumQuantity, (q[id] ?? 0) + delta));
		return {
			...q,
			[id]: next
		};
	});
	const days = (0, import_react.useMemo)(() => {
		const pad = isoDay(new Date(cursor.getFullYear(), cursor.getMonth(), 1)) - 1;
		const count = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
		const cells = Array.from({ length: pad }, () => null);
		for (let i = 1; i <= count; i++) cells.push(new Date(cursor.getFullYear(), cursor.getMonth(), i));
		return cells;
	}, [cursor]);
	if (placed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Success, {
		date: selectedDate,
		slot,
		tickets: totalTickets,
		total,
		program: program?.title
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 pb-40 pt-28 sm:px-6 lg:pt-32",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: "/",
				className: "inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 14 }), " Retour"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-6 text-4xl sm:text-6xl",
				children: ["Vos billets ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-ice",
					children: "FESTI-ICE"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-xl text-sm text-muted-foreground",
				children: "Date, séance d'arrivée, billets, paiement. Quatre étapes, aucun frais surprise."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Steps, { step }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-8 lg:grid-cols-[1fr_360px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
							active: step >= 1,
							n: "01",
							title: "Choisir une date",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": "Mois précédent",
											onClick: () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1)),
											className: "rounded-full border border-border px-3 py-1.5 text-sm",
											children: "‹"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-display text-lg",
											children: [
												MONTHS[cursor.getMonth()],
												" ",
												cursor.getFullYear()
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": "Mois suivant",
											onClick: () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1)),
											className: "rounded-full border border-border px-3 py-1.5 text-sm",
											children: "›"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-5 grid grid-cols-7 gap-1 text-center text-[0.65rem] uppercase tracking-[0.12em] text-muted-foreground",
									children: DAY_LETTERS.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: d }, i))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 grid grid-cols-7 gap-1",
									children: days.map((d, i) => {
										if (!d) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}, i);
										const p = programForDate(d);
										const key = toKey(d);
										const past = d < new Date((/* @__PURE__ */ new Date()).toDateString());
										const disabled = !p || past || p.status === "SOLD_OUT";
										const selected = key === dateKey;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											disabled,
											"aria-label": `${d.getDate()} ${MONTHS[d.getMonth()]}${p ? ` — ${p.title}` : " — fermé"}`,
											onClick: () => {
												setDateKey(key);
												setSlot(void 0);
												setStep(2);
											},
											className: `aspect-square rounded-lg border text-sm transition-colors ${selected ? "border-primary bg-primary text-primary-foreground font-bold" : disabled ? "border-transparent text-muted-foreground/35" : "border-border/70 hover:border-primary/70"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block leading-none",
												children: d.getDate()
											}), !disabled && !selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `mx-auto mt-1 block h-1 w-1 rounded-full ${p?.status === "LOW_AVAILABILITY" ? "bg-coral" : "bg-primary"}` })]
										}, key);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 flex flex-wrap gap-4 text-xs text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "inline-block h-1.5 w-1.5 rounded-full bg-primary" }), " Disponible"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "inline-block h-1.5 w-1.5 rounded-full bg-coral" }), " Peu de disponibilités"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground/60",
											children: "Grisé — fermé ou complet"
										})
									]
								})
							]
						}),
						step >= 2 && selectedDate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
							active: true,
							n: "02",
							title: "Choisir votre heure d'arrivée",
							children: [program && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-5 rounded-xl border border-primary/25 bg-primary/5 p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "eyebrow",
										children: [
											program.dayLongFr,
											" · ",
											program.styles
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl",
										children: program.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-sm text-muted-foreground",
										children: [
											program.startTime,
											" – ",
											program.endTime,
											" · ",
											program.note
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-2 sm:grid-cols-5",
								children: timeSlots.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setSlot(t);
										setStep(3);
									},
									className: `rounded-full border py-2.5 text-sm font-semibold transition-colors ${slot === t ? "border-primary bg-primary text-primary-foreground" : "border-border/70 hover:border-primary/70"}`,
									children: t
								}, t))
							})]
						}),
						step >= 3 && slot && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
							active: true,
							n: "03",
							title: "Choisir vos billets",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "divide-y divide-border/50",
									children: ticketTypes.filter((t) => t.active).sort((a, b) => a.sortOrder - b.sortOrder).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center gap-4 py-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0 flex-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-semibold",
													children: t.nameFr
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-0.5 text-xs text-muted-foreground",
													children: t.descriptionFr
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-sm font-bold text-primary",
													children: formatCents(t.priceCents)
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex shrink-0 items-center gap-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"aria-label": `Retirer un billet ${t.nameFr}`,
													onClick: () => setQty(t.id, -1),
													className: "grid h-9 w-9 place-items-center rounded-full border border-border disabled:opacity-30",
													disabled: (quantities[t.id] ?? 0) === 0,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 15 })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-5 text-center text-sm font-bold tabular-nums",
													children: quantities[t.id] ?? 0
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"aria-label": `Ajouter un billet ${t.nameFr}`,
													onClick: () => setQty(t.id, 1),
													className: "grid h-9 w-9 place-items-center rounded-full border border-primary/60 text-primary",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 })
												})
											]
										})]
									}, t.id))
								}),
								errors.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									role: "alert",
									className: "mt-4 space-y-1 rounded-xl border border-destructive/50 bg-destructive/10 p-4 text-sm",
									children: errors.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: e }, e))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6 rounded-xl border border-aurora/30 bg-aurora/5 p-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex cursor-pointer items-start gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: flex,
											onChange: (e) => setFlex(e.target.checked),
											className: "mt-1 h-4 w-4 accent-[var(--cyan-ice)]"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-sm font-semibold",
											children: [
												flexOption.nameFr,
												" — ",
												formatCents(flexOption.priceCents),
												" / billet"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-xs text-muted-foreground",
											children: flexOption.descriptionFr
										})] })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: !canContinueTickets,
									onClick: () => setStep(4),
									className: "mt-6 w-full rounded-full bg-primary py-4 text-sm font-bold uppercase tracking-[0.18em] text-primary-foreground disabled:opacity-40",
									children: "Continuer"
								})
							]
						}),
						step >= 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
							active: true,
							n: "04",
							title: "Vos informations",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 sm:grid-cols-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Prénom",
											name: "firstName"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Nom",
											name: "lastName"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Courriel",
											name: "email",
											type: "email"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Téléphone",
											name: "phone",
											type: "tel"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Code postal",
											name: "postal"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											htmlFor: "lang",
											className: "mb-1.5 block text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground",
											children: "Langue des communications"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											id: "lang",
											className: "w-full rounded-lg border border-input bg-card px-3 py-3 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Français" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "English" })]
										})] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-5 flex items-start gap-3 text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										className: "mt-0.5 h-4 w-4 accent-[var(--cyan-ice)]"
									}), "Je souhaite recevoir les nouvelles et offres FESTI-ICE. (facultatif)"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setStep(5),
									className: "mt-6 w-full rounded-full bg-primary py-4 text-sm font-bold uppercase tracking-[0.18em] text-primary-foreground",
									children: "Aller au paiement"
								})
							]
						}),
						step >= 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
							active: true,
							n: "05",
							title: "Paiement",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-dashed border-border p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "mx-auto mb-3 text-primary" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-semibold",
											children: "Paiement sécurisé"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mx-auto mt-2 max-w-sm text-xs text-muted-foreground",
											children: "Le module de paiement (carte, Apple\xA0Pay, Google\xA0Pay) est branché à la prochaine phase, avec vérification serveur et émission des billets QR."
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "promo",
										className: "text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground",
										children: "Code promotionnel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "promo",
										value: promo,
										onChange: (e) => setPromo(e.target.value),
										className: "mt-1.5 w-full rounded-lg border border-input bg-card px-3 py-3 text-sm",
										placeholder: "Facultatif"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setPlaced(true),
									className: "mt-6 w-full rounded-full bg-primary py-4 text-sm font-bold uppercase tracking-[0.18em] text-primary-foreground glow",
									children: ["Payer ", formatCents(total)]
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "lg:sticky lg:top-28 lg:self-start",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "surface-frost rounded-2xl p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Votre commande"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-4 space-y-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Date",
										value: selectedDate ? `${selectedDate.getDate()} ${MONTHS[selectedDate.getMonth()]}` : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Heure",
										value: slot ?? "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Ambiance",
										value: program?.title ?? "—"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-4 h-px bg-border/60" }),
							lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "Aucun billet sélectionné."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "space-y-2 text-sm",
								children: [
									lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: `${l.qty} × ${l.type.nameFr}`,
										value: formatCents(l.qty * l.type.priceCents)
									}, l.type.id)),
									flex && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: `${totalTickets} × Option Flex Météo`,
										value: formatCents(flexTotal)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-3 h-px bg-border/60" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Sous-total",
										value: formatCents(taxable)
									}),
									taxLines.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: t.code,
										value: formatCents(t.cents),
										muted: true
									}, t.code)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-3 h-px bg-border/60" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display text-lg",
											children: "Total"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display text-lg text-ice",
											children: formatCents(total)
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 flex items-start gap-2 text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ticket, {
									size: 14,
									className: "mt-0.5 shrink-0"
								}), "Aucuns frais cachés. Les taxes applicables sont affichées ci-dessus."]
							})
						]
					})
				})]
			})
		]
	});
}
function Steps({ step }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "mt-8 flex flex-wrap gap-2 text-[0.65rem] uppercase tracking-[0.16em]",
		children: [
			"Date",
			"Heure",
			"Billets",
			"Infos",
			"Paiement"
		].map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: `rounded-full border px-3 py-1.5 font-semibold ${step > i + 1 ? "border-primary/50 text-primary" : step === i + 1 ? "border-primary bg-primary text-primary-foreground" : "border-border/60 text-muted-foreground"}`,
			children: [step > i + 1 ? "✓ " : "", l]
		}, l))
	});
}
function Panel({ n, title, children, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: `rounded-2xl border border-border/60 bg-card/60 p-5 sm:p-6 ${active ? "" : "opacity-50"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "mb-5 flex items-baseline gap-3 text-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-ice",
				children: n
			}), title]
		}), children]
	});
}
function Row({ label, value, muted }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: muted ? "text-muted-foreground" : "",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: `shrink-0 tabular-nums ${muted ? "text-muted-foreground" : "font-semibold"}`,
			children: value
		})]
	});
}
function Field({ label, name, type = "text" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		htmlFor: name,
		className: "mb-1.5 block text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		id: name,
		name,
		type,
		className: "w-full rounded-lg border border-input bg-card px-3 py-3 text-sm"
	})] });
}
function Success({ date, slot, tickets, total, program }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 pb-32 pt-32 text-center sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid h-16 w-16 place-items-center rounded-full bg-primary text-primary-foreground glow",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 30 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-8 text-4xl sm:text-5xl",
				children: "À bientôt sur la glace."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted-foreground",
				children: "Votre commande est enregistrée. Les billets QR seront transmis par courriel dès l'activation du module de paiement."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "surface-frost mt-8 space-y-3 rounded-2xl p-6 text-left text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Date",
						value: date ? `${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Séance d'arrivée",
						value: slot ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Ambiance de la soirée",
						value: program ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Billets",
						value: String(tickets)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Total payé",
						value: formatCents(total)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap justify-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: venue.directionsUrl,
					target: "_blank",
					rel: "noreferrer",
					className: "rounded-full border border-primary/60 px-6 py-3 text-xs font-bold uppercase tracking-[0.18em] text-primary",
					children: "Itinéraire"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/",
					className: "rounded-full bg-primary px-6 py-3 text-xs font-bold uppercase tracking-[0.18em] text-primary-foreground",
					children: "Préparer ma visite"
				})]
			})
		]
	});
}
//#endregion
export { BilletsPage as component };
