import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billets-DTngiR73.js
var $$splitComponentImporter = () => import("./billets-DC4jm1tI.mjs");
var Route = createFileRoute("/billets")({
	validateSearch: (search) => ({
		date: typeof search["date"] === "string" ? search["date"] : void 0,
		theme: typeof search["theme"] === "string" ? search["theme"] : void 0
	}),
	head: () => ({ meta: [
		{ title: "Billets FESTI-ICE — Patinage illuminé au Havana Resort" },
		{
			name: "description",
			content: "Choisissez votre date, votre séance et vos billets pour FESTI-ICE, le parcours sur glace illuminé du Havana Resort à Maricourt."
		},
		{
			property: "og:title",
			content: "Billets FESTI-ICE"
		},
		{
			property: "og:description",
			content: "Calendrier, séances d'arrivée, tarifs familiaux et Option Flex Météo. Achat en ligne sécurisé."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
