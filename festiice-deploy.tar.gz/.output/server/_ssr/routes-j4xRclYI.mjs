import { r as __toESM } from "../_runtime.mjs";
import { a as practicalInfo, c as season, d as ticketTypes, i as formatCents, n as faq, o as programs, p as venue, s as routeSegments, t as accommodations } from "./festi-data-xAMTw4eE.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Snowflake, c as Plus, f as MapPin, g as ChevronDown, h as ChevronLeft, i as Sparkles, l as Music4, m as ChevronRight, n as Users, p as Clock, s as RotateCcw, t as X, u as Minus } from "../_libs/lucide-react.mjs";
import { t as Route } from "./routes-BoZwAqI3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-j4xRclYI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var hero_festi_ice_default = "/assets/hero-festi-ice-i7dSCSCs.jpg";
var ambiance_tunnel_default = "/assets/ambiance-tunnel-Ujhg7UiV.jpg";
var havana_winter_default = "/assets/havana-winter-5DCWxEo1.jpg";
var ambiance_famille_default = "/assets/ambiance-famille-D226qPNj.jpg";
var havana_sign_default = "/assets/havana-sign-DcZ3-eQF.jpeg";
var havana_fleurs_geantes_default = "/assets/havana-fleurs-geantes-BoJlEgBn.jpeg";
var havana_arbre_lumieres_webp_asset_default = {
	version: 1,
	asset_id: "c8b0d49b-8970-44c1-8d88-0907246bc6ed",
	project_id: "77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae",
	url: "/__l5e/assets-v1/c8b0d49b-8970-44c1-8d88-0907246bc6ed/havana-arbre-lumieres.webp",
	r2_key: "a/v1/77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae/c8b0d49b-8970-44c1-8d88-0907246bc6ed/havana-arbre-lumieres.webp",
	original_filename: "havana-arbre-lumieres.webp",
	size: 505718,
	content_type: "image/webp",
	created_at: "2026-09-05T13:05:22Z"
};
var havana_train_default = "/assets/havana-train-DLAjZChj.jpeg";
var havana_la_playera_default = "/assets/havana-la-playera-CW1LSjsB.jpeg";
var havana_mojito_bar_default = "/assets/havana-mojito-bar-BCMVxMaT.jpeg";
var havana_guirlandes_webp_asset_default = {
	version: 1,
	asset_id: "f420d1cd-9180-42fa-8fd0-fe5460933f83",
	project_id: "77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae",
	url: "/__l5e/assets-v1/f420d1cd-9180-42fa-8fd0-fe5460933f83/havana-guirlandes.webp",
	r2_key: "a/v1/77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae/f420d1cd-9180-42fa-8fd0-fe5460933f83/havana-guirlandes.webp",
	original_filename: "havana-guirlandes.webp",
	size: 211348,
	content_type: "image/webp",
	created_at: "2026-09-05T13:05:31Z"
};
var havana_feu_exterieur_webp_asset_default = {
	version: 1,
	asset_id: "d10e41e5-e713-469b-9039-a473b1d326ef",
	project_id: "77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae",
	url: "/__l5e/assets-v1/d10e41e5-e713-469b-9039-a473b1d326ef/havana-feu-exterieur.webp",
	r2_key: "a/v1/77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae/d10e41e5-e713-469b-9039-a473b1d326ef/havana-feu-exterieur.webp",
	original_filename: "havana-feu-exterieur.webp",
	size: 324926,
	content_type: "image/webp",
	created_at: "2026-09-05T13:05:25Z"
};
var havana_guirlandes_pieux_webp_asset_default = {
	version: 1,
	asset_id: "b5749570-3a1b-42ef-a1e4-1aa8f8cf130a",
	project_id: "77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae",
	url: "/__l5e/assets-v1/b5749570-3a1b-42ef-a1e4-1aa8f8cf130a/havana-guirlandes-pieux.webp",
	r2_key: "a/v1/77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae/b5749570-3a1b-42ef-a1e4-1aa8f8cf130a/havana-guirlandes-pieux.webp",
	original_filename: "havana-guirlandes-pieux.webp",
	size: 196588,
	content_type: "image/webp",
	created_at: "2026-09-06T07:46:00Z"
};
var havana_photobooth_webp_asset_default = {
	version: 1,
	asset_id: "58ff308c-2190-40c8-97b3-838baaa05c15",
	project_id: "77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae",
	url: "/__l5e/assets-v1/58ff308c-2190-40c8-97b3-838baaa05c15/havana-photobooth.webp",
	r2_key: "a/v1/77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae/58ff308c-2190-40c8-97b3-838baaa05c15/havana-photobooth.webp",
	original_filename: "havana-photobooth.webp",
	size: 184444,
	content_type: "image/webp",
	created_at: "2026-09-06T07:46:05Z"
};
var havana_foyer_terrasse_webp_asset_default = {
	version: 1,
	asset_id: "a76381be-44ee-4735-a665-2663b0e2cb2a",
	project_id: "77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae",
	url: "/__l5e/assets-v1/a76381be-44ee-4735-a665-2663b0e2cb2a/havana-foyer-terrasse.webp",
	r2_key: "a/v1/77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae/a76381be-44ee-4735-a665-2663b0e2cb2a/havana-foyer-terrasse.webp",
	original_filename: "havana-foyer-terrasse.webp",
	size: 237902,
	content_type: "image/webp",
	created_at: "2026-09-06T07:46:10Z"
};
var havana_camion_pompier_webp_asset_default = {
	version: 1,
	asset_id: "2e20e4bc-b705-479e-ab6d-a2e8c740da67",
	project_id: "77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae",
	url: "/__l5e/assets-v1/2e20e4bc-b705-479e-ab6d-a2e8c740da67/havana-camion-pompier.webp",
	r2_key: "a/v1/77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae/2e20e4bc-b705-479e-ab6d-a2e8c740da67/havana-camion-pompier.webp",
	original_filename: "havana-camion-pompier.webp",
	size: 238634,
	content_type: "image/webp",
	created_at: "2026-09-06T07:46:14Z"
};
var havana_arbre_geant_webp_asset_default = {
	version: 1,
	asset_id: "b0c7d83d-8e5c-4995-9933-3cd593f2cf29",
	project_id: "77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae",
	url: "/__l5e/assets-v1/b0c7d83d-8e5c-4995-9933-3cd593f2cf29/havana-arbre-geant.webp",
	r2_key: "a/v1/77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae/b0c7d83d-8e5c-4995-9933-3cd593f2cf29/havana-arbre-geant.webp",
	original_filename: "havana-arbre-geant.webp",
	size: 317500,
	content_type: "image/webp",
	created_at: "2026-09-06T07:46:19Z"
};
var havana_rue_train_default = "/assets/havana-rue-train-ACFF803R.jpeg";
var havana_rue_guirlandes_webp_asset_default = {
	version: 1,
	asset_id: "f088299c-5119-4abe-b29a-a45ebbdb02ed",
	project_id: "77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae",
	url: "/__l5e/assets-v1/f088299c-5119-4abe-b29a-a45ebbdb02ed/havana-rue-guirlandes.webp",
	r2_key: "a/v1/77a3d4d4-f8e5-4f4f-a02e-e1b102bb3eae/f088299c-5119-4abe-b29a-a45ebbdb02ed/havana-rue-guirlandes.webp",
	original_filename: "havana-rue-guirlandes.webp",
	size: 165734,
	content_type: "image/webp",
	created_at: "2026-09-06T07:46:33Z"
};
var havana_carte_default = "/assets/havana-carte-D1Y8f0RQ.jpeg";
/**
* Real photography of the Havana Resort — the venue that will host FESTI-ICE.
*
* IMPORTANT EDITORIAL RULE: these are photographs of the existing resort, not
* of a past FESTI-ICE edition (2026-2027 is the inaugural season). Captions
* must never claim otherwise.
*/
var havanaPhotos = {
	sign: {
		key: "havana-sign",
		url: havana_sign_default,
		width: 1448,
		height: 1086,
		focal: "50% 45%",
		altFr: "Enseigne lumineuse Havana Resort et voiture vintage éclairées la nuit en forêt",
		altEn: "Illuminated Havana Resort sign and vintage car at night in the forest",
		captionFr: "Le Havana Resort, site hôte de FESTI-ICE",
		captionEn: "Havana Resort, home of FESTI-ICE",
		category: "HAVANA_DESTINATION"
	},
	fleurs: {
		key: "havana-fleurs-geantes",
		url: havana_fleurs_geantes_default,
		width: 1086,
		height: 1448,
		focal: "50% 40%",
		altFr: "Grande fleur lumineuse et cygne décoratif illuminés dans le boisé du Havana Resort",
		altEn: "Giant illuminated flower and decorative swan in the Havana Resort woods",
		captionFr: "Installations lumineuses grand format au Havana Resort",
		captionEn: "Large-scale light installations at Havana Resort",
		category: "LIGHT_INSTALLATION"
	},
	arbre: {
		key: "havana-arbre-lumieres",
		url: havana_arbre_lumieres_webp_asset_default.url,
		width: 1086,
		height: 1448,
		focal: "50% 40%",
		altFr: "Arbre mature entièrement habillé de lumières blanches et bleues la nuit",
		altEn: "Mature tree fully wrapped in white and blue lights at night",
		captionFr: "Découvrez le décor qui accueillera FESTI-ICE cet hiver",
		captionEn: "Discover the destination that will host FESTI-ICE this winter",
		category: "LIGHT_INSTALLATION"
	},
	train: {
		key: "havana-train",
		url: havana_train_default,
		width: 1086,
		height: 1448,
		focal: "35% 50%",
		altFr: "Petit train du Havana Resort stationné sous des guirlandes lumineuses",
		altEn: "Havana Resort trolley train parked under string lights",
		captionFr: "Un resort à découvrir autrement",
		captionEn: "A resort to discover differently",
		category: "FAMILY"
	},
	playera: {
		key: "havana-la-playera",
		url: havana_la_playera_default,
		width: 1448,
		height: 1086,
		focal: "65% 45%",
		altFr: "Bâtiment tropical La Playera illuminé le soir au Havana Resort",
		altEn: "La Playera tropical building lit up in the evening at Havana Resort",
		captionFr: "La Playera, l'un des espaces du domaine",
		captionEn: "La Playera, one of the resort's spaces",
		category: "HAVANA_DESTINATION"
	},
	mojito: {
		key: "havana-mojito-bar",
		url: havana_mojito_bar_default,
		width: 1448,
		height: 1086,
		focal: "50% 45%",
		altFr: "Aire de rassemblement extérieure du Havana Resort décorée de lumières",
		altEn: "Outdoor gathering area at Havana Resort decorated with lights",
		captionFr: "Les aires de rassemblement du domaine",
		captionEn: "The resort's gathering areas",
		category: "FOOD_AREA"
	},
	guirlandes: {
		key: "havana-guirlandes",
		url: havana_guirlandes_webp_asset_default.url,
		width: 1086,
		height: 1448,
		focal: "50% 40%",
		altFr: "Zone piétonne du Havana Resort sous des rangées de guirlandes lumineuses",
		altEn: "Havana Resort pedestrian zone under rows of string lights",
		captionFr: "La zone piétonne, une fois la nuit tombée",
		captionEn: "The pedestrian zone after dark",
		category: "EXPERIENCE"
	},
	feu: {
		key: "havana-feu-exterieur",
		url: havana_feu_exterieur_webp_asset_default.url,
		width: 1086,
		height: 1448,
		focal: "50% 45%",
		altFr: "Foyer extérieur entouré de chaises Adirondack au Havana Resort le soir",
		altEn: "Outdoor fire pit surrounded by Adirondack chairs at Havana Resort",
		captionFr: "Les espaces chaleureux du Havana Resort",
		captionEn: "Havana Resort's warm gathering spots",
		category: "FOOD_AREA"
	},
	pieux: {
		key: "havana-guirlandes-pieux",
		url: havana_guirlandes_pieux_webp_asset_default.url,
		width: 895,
		height: 1195,
		focal: "50% 50%",
		altFr: "Guirlandes lumineuses tendues entre des pieux de bois colorés au Havana Resort",
		altEn: "String lights hung between colourful wooden posts at Havana Resort",
		captionFr: "Les allées guirlandées du domaine",
		captionEn: "The resort's string-lit pathways",
		category: "LIGHT_INSTALLATION"
	},
	photobooth: {
		key: "havana-photobooth",
		url: havana_photobooth_webp_asset_default.url,
		width: 895,
		height: 1185,
		focal: "50% 45%",
		altFr: "Coin photo Havana Resort décoré de lumières blanches, palmiers et étoiles",
		altEn: "Havana Resort photo booth decorated with white lights, palm trees and stars",
		captionFr: "Le coin photo du Havana Resort",
		captionEn: "Havana Resort's photo corner",
		category: "FAMILY"
	},
	foyer: {
		key: "havana-foyer-terrasse",
		url: havana_foyer_terrasse_webp_asset_default.url,
		width: 895,
		height: 1185,
		focal: "50% 50%",
		altFr: "Foyer allumé entouré de chaises Adirondack devant le casse-croûte du Havana Resort",
		altEn: "Lit fire pit surrounded by Adirondack chairs by the Havana Resort snack bar",
		captionFr: "Se réchauffer près du foyer",
		captionEn: "Warming up by the fire",
		category: "FOOD_AREA"
	},
	pompier: {
		key: "havana-camion-pompier",
		url: havana_camion_pompier_webp_asset_default.url,
		width: 895,
		height: 1183,
		focal: "50% 50%",
		altFr: "Camion de pompier vintage rouge illuminé de guirlandes au Havana Resort",
		altEn: "Vintage red fire truck covered in string lights at Havana Resort",
		captionFr: "Le camion de pompier illuminé",
		captionEn: "The illuminated vintage fire truck",
		category: "LIGHT_INSTALLATION"
	},
	arbreGeant: {
		key: "havana-arbre-geant",
		url: havana_arbre_geant_webp_asset_default.url,
		width: 895,
		height: 1185,
		focal: "50% 45%",
		altFr: "Très grand arbre entièrement habillé de lumières dorées et bleues",
		altEn: "Large tree fully wrapped in golden and blue lights",
		captionFr: "L'arbre-signature du domaine",
		captionEn: "The resort's signature tree",
		category: "LIGHT_INSTALLATION"
	},
	rueTrain: {
		key: "havana-rue-train",
		url: havana_rue_train_default,
		width: 895,
		height: 1180,
		focal: "50% 45%",
		altFr: "Petit train du Havana Resort stationné sous des rangées de guirlandes lumineuses",
		altEn: "Havana Resort's little train parked under rows of string lights",
		captionFr: "Le petit train et la rue principale",
		captionEn: "The little train and the main street",
		category: "EXPERIENCE"
	},
	rueGuirlandes: {
		key: "havana-rue-guirlandes",
		url: havana_rue_guirlandes_webp_asset_default.url,
		width: 895,
		height: 1185,
		focal: "50% 55%",
		altFr: "Ciel de guirlandes lumineuses au-dessus de la zone piétonne du Havana Resort",
		altEn: "Canopy of string lights above the Havana Resort pedestrian zone",
		captionFr: "Un ciel de lumières au-dessus du domaine",
		captionEn: "A sky of lights above the resort",
		category: "EXPERIENCE"
	}
};
havanaPhotos.train, havanaPhotos.playera, havanaPhotos.guirlandes, havanaPhotos.mojito, havanaPhotos.feu, havanaPhotos.fleurs, havanaPhotos.arbreGeant, havanaPhotos.rueTrain, havanaPhotos.pompier, havanaPhotos.foyer, havanaPhotos.photobooth, havanaPhotos.pieux, havanaPhotos.rueGuirlandes;
/** Official Havana Resort property map (supplied by the resort). */
var havanaMap = {
	url: havana_carte_default,
	width: 1920,
	height: 1242,
	altFr: "Carte officielle du Camping Havana Resort montrant les rues, le lac, les chalets et les services",
	altEn: "Official Camping Havana Resort map showing streets, the lake, chalets and services"
};
function PhotoLightbox({ photos, index, onClose, onIndexChange }) {
	const [touchX, setTouchX] = (0, import_react.useState)(null);
	const open = index !== null;
	const go = (0, import_react.useCallback)((delta) => {
		if (index === null) return;
		onIndexChange((index + delta + photos.length) % photos.length);
	}, [
		index,
		onIndexChange,
		photos.length
	]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
			if (e.key === "ArrowRight") go(1);
			if (e.key === "ArrowLeft") go(-1);
		};
		document.addEventListener("keydown", onKey);
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.removeEventListener("keydown", onKey);
			document.body.style.overflow = prev;
		};
	}, [
		open,
		go,
		onClose
	]);
	if (index === null) return null;
	const photo = photos[index];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Galerie photo du Havana Resort",
		className: "fixed inset-0 z-[100] flex flex-col bg-midnight/95 backdrop-blur-sm",
		onTouchStart: (e) => setTouchX(e.touches[0]?.clientX ?? null),
		onTouchEnd: (e) => {
			if (touchX === null) return;
			const dx = (e.changedTouches[0]?.clientX ?? touchX) - touchX;
			if (Math.abs(dx) > 50) go(dx < 0 ? 1 : -1);
			setTouchX(null);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-4 py-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold uppercase tracking-[0.2em] text-silver",
					children: [
						index + 1,
						" / ",
						photos.length
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					"aria-label": "Fermer la galerie",
					className: "grid h-11 w-11 place-items-center rounded-full border border-border/70 text-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex min-h-0 flex-1 items-center justify-center px-2 sm:px-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => go(-1),
						"aria-label": "Photo précédente",
						className: "absolute left-2 hidden h-12 w-12 place-items-center rounded-full border border-border/70 text-foreground sm:grid",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { size: 20 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: photo.url,
						alt: photo.altFr,
						width: photo.width,
						height: photo.height,
						className: "max-h-full max-w-full rounded-xl object-contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => go(1),
						"aria-label": "Photo suivante",
						className: "absolute right-2 hidden h-12 w-12 place-items-center rounded-full border border-border/70 text-foreground sm:grid",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 20 })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 py-6 text-center text-sm text-silver sm:px-6",
				children: photo.captionFr
			})
		]
	});
}
var categories = [
	{
		id: "domaine",
		label: "Le domaine",
		blurb: "Le Havana Resort tel qu'il est aujourd'hui : ses rues, ses terrasses et son petit train.",
		photos: [
			havanaPhotos.sign,
			havanaPhotos.playera,
			havanaPhotos.rueTrain,
			havanaPhotos.train,
			havanaPhotos.mojito
		]
	},
	{
		id: "lumieres",
		label: "Les lumières",
		blurb: "Des installations lumineuses grand format déjà présentes sur le domaine.",
		photos: [
			havanaPhotos.arbreGeant,
			havanaPhotos.fleurs,
			havanaPhotos.arbre,
			havanaPhotos.pompier,
			havanaPhotos.pieux
		]
	},
	{
		id: "ambiances",
		label: "Les ambiances",
		blurb: "Les allées guirlandées, les foyers extérieurs et les coins photo.",
		photos: [
			havanaPhotos.rueGuirlandes,
			havanaPhotos.guirlandes,
			havanaPhotos.foyer,
			havanaPhotos.feu,
			havanaPhotos.photobooth
		]
	}
];
function HavanaGallery() {
	const [catIndex, setCatIndex] = (0, import_react.useState)(0);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	const touchX = (0, import_react.useRef)(null);
	const category = categories[catIndex];
	const photos = category.photos;
	const current = photos[index] ?? photos[0];
	const go = (delta) => setIndex((i) => (i + delta + photos.length) % photos.length);
	const selectCategory = (i) => {
		setCatIndex(i);
		setIndex(0);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "px-4 py-24 sm:px-6 lg:py-32",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Découvrez l'expérience"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 max-w-2xl text-[clamp(2rem,6vw,3.5rem)]",
					children: ["Le Havana Resort, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-ice",
						children: "une fois la nuit tombée."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-xl text-sm leading-relaxed text-muted-foreground",
					children: "Photos actuelles du domaine qui accueillera FESTI-ICE. Le parcours sur glace sera présenté pour la première fois lors de la saison inaugurale."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 flex flex-wrap gap-2",
					role: "tablist",
					"aria-label": "Catégories de photos",
					children: categories.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": i === catIndex,
						onClick: () => selectCategory(i),
						className: `rounded-full border px-4 py-2 text-xs uppercase tracking-widest transition-colors ${i === catIndex ? "border-primary bg-primary/10 text-primary" : "border-border/60 text-muted-foreground hover:text-foreground"}`,
						children: c.label
					}, c.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted-foreground",
					children: category.blurb
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mt-6 overflow-hidden rounded-2xl border border-border/50 shadow-lg shadow-background/40",
					onTouchStart: (e) => {
						touchX.current = e.touches[0]?.clientX ?? null;
					},
					onTouchEnd: (e) => {
						const start = touchX.current;
						const end = e.changedTouches[0]?.clientX ?? null;
						if (start === null || end === null) return;
						if (Math.abs(end - start) > 40) go(end < start ? 1 : -1);
						touchX.current = null;
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setLightbox(index),
							className: "block w-full focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary",
							"aria-label": `Agrandir : ${current.captionFr}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: current.url,
								alt: current.altFr,
								width: current.width,
								height: current.height,
								loading: "lazy",
								decoding: "async",
								sizes: "(min-width: 1024px) 1024px, 100vw",
								style: { objectPosition: current.focal },
								className: "aspect-[4/5] w-full animate-fade-in object-cover sm:aspect-[16/9]"
							}, current.key)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 bg-gradient-to-t from-background/90 to-transparent p-4 sm:p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-md text-sm text-foreground/90",
								children: current.captionFr
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "shrink-0 text-xs tabular-nums text-muted-foreground",
								children: [
									index + 1,
									" / ",
									photos.length
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => go(-1),
							"aria-label": "Photo précédente",
							className: "absolute left-3 top-1/2 hidden -translate-y-1/2 rounded-full border border-border/60 bg-background/70 p-2 backdrop-blur transition-colors hover:bg-background sm:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => go(1),
							"aria-label": "Photo suivante",
							className: "absolute right-3 top-1/2 hidden -translate-y-1/2 rounded-full border border-border/60 bg-background/70 p-2 backdrop-blur transition-colors hover:bg-background sm:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 hidden gap-3 sm:grid sm:grid-cols-5",
					children: photos.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setIndex(i),
						"aria-label": `Voir : ${p.captionFr}`,
						"aria-current": i === index,
						className: `block w-full overflow-hidden rounded-lg border transition-opacity ${i === index ? "border-primary opacity-100" : "border-border/50 opacity-60 hover:opacity-100"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: p.url,
							alt: "",
							width: p.width,
							height: p.height,
							loading: "lazy",
							decoding: "async",
							sizes: "200px",
							style: { objectPosition: p.focal },
							className: "aspect-[4/3] w-full object-cover"
						})
					}) }, p.key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex justify-center gap-2 sm:hidden",
					children: photos.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1 rounded-full transition-all ${i === index ? "w-6 bg-primary" : "w-2 bg-border"}` }, p.key))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoLightbox, {
			photos,
			index: lightbox,
			onClose: () => setLightbox(null),
			onIndexChange: (i) => {
				setLightbox(i);
				setIndex(i);
			}
		})]
	});
}
/** Approximate positions on the official resort map, used for orientation only. */
var pois = [
	{
		id: "accueil",
		label: "Accueil",
		detail: "Arrivée, billetterie et validation des codes QR.",
		x: 16,
		y: 62
	},
	{
		id: "stationnement",
		label: "Stationnement",
		detail: "Sur place, gratuit.",
		x: 9,
		y: 40
	},
	{
		id: "parcours",
		label: "Parcours sur glace",
		detail: "Le tracé illuminé suit les rues du domaine.",
		x: 52,
		y: 48
	},
	{
		id: "restauration",
		label: "Restauration",
		detail: "Casse-croûte et aires de rassemblement chauffées.",
		x: 38,
		y: 66
	},
	{
		id: "hebergements",
		label: "Hébergements",
		detail: "Chalets, villas, cabanas, Coolbox et condos-hôtel.",
		x: 72,
		y: 33
	},
	{
		id: "lac",
		label: "Le lac",
		detail: "Cœur du domaine de 263 acres.",
		x: 62,
		y: 70
	}
];
function HavanaMap() {
	const [zoom, setZoom] = (0, import_react.useState)(1);
	const [offset, setOffset] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const [active, setActive] = (0, import_react.useState)(null);
	const drag = (0, import_react.useRef)(null);
	const reset = () => {
		setZoom(1);
		setOffset({
			x: 0,
			y: 0
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "carte",
		className: "px-4 py-24 sm:px-6 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Explorez le domaine"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 max-w-2xl text-[clamp(2rem,6vw,3.5rem)]",
					children: ["La carte du ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-ice",
						children: "Havana Resort."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-xl text-sm leading-relaxed text-muted-foreground",
					children: "263 acres, un lac, des rues nommées et des hébergements quatre-saisons. Déplacez et agrandissez la carte, puis touchez un repère pour en savoir plus."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 grid gap-6 lg:grid-cols-[1.6fr_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden rounded-2xl border border-border/50 bg-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative aspect-[16/10] cursor-grab touch-pan-y active:cursor-grabbing",
							onPointerDown: (e) => {
								drag.current = {
									x: e.clientX,
									y: e.clientY,
									ox: offset.x,
									oy: offset.y
								};
								e.currentTarget.setPointerCapture(e.pointerId);
							},
							onPointerMove: (e) => {
								const d = drag.current;
								if (!d) return;
								setOffset({
									x: d.ox + (e.clientX - d.x),
									y: d.oy + (e.clientY - d.y)
								});
							},
							onPointerUp: () => {
								drag.current = null;
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-0 origin-center transition-transform duration-150",
								style: { transform: `translate(${offset.x}px, ${offset.y}px) scale(${zoom})` },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: havanaMap.url,
									alt: havanaMap.altFr,
									width: havanaMap.width,
									height: havanaMap.height,
									loading: "lazy",
									decoding: "async",
									sizes: "(min-width: 1024px) 900px, 100vw",
									className: "size-full select-none object-cover",
									draggable: false
								}), pois.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setActive(p.id),
									"aria-label": p.label,
									className: "absolute -translate-x-1/2 -translate-y-1/2",
									style: {
										left: `${p.x}%`,
										top: `${p.y}%`
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `block rounded-full border-2 shadow-md transition-all ${active === p.id ? "size-4 border-primary bg-primary" : "size-3 border-background bg-primary/80 hover:size-4"}` })
								}, p.id))]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute right-3 top-3 flex flex-col gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setZoom((z) => Math.min(3, +(z + .4).toFixed(2))),
									"aria-label": "Agrandir la carte",
									className: "rounded-full border border-border/60 bg-background/80 p-2 backdrop-blur",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setZoom((z) => Math.max(1, +(z - .4).toFixed(2))),
									"aria-label": "Réduire la carte",
									className: "rounded-full border border-border/60 bg-background/80 p-2 backdrop-blur",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: reset,
									"aria-label": "Recentrer la carte",
									className: "rounded-full border border-border/60 bg-background/80 p-2 backdrop-blur",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-2 sm:grid-cols-2 lg:grid-cols-1",
						children: pois.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setActive(p.id),
							className: `w-full rounded-xl border p-4 text-left transition-colors ${active === p.id ? "border-primary bg-primary/10" : "border-border/50 hover:border-border"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium",
								children: p.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-xs leading-relaxed text-muted-foreground",
								children: p.detail
							})]
						}) }, p.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-muted-foreground",
					children: "Repères approximatifs — carte officielle du Camping Havana Resort."
				})
			]
		})
	});
}
var fallback = {
	season: {
		label: season.label,
		isInauguralSeason: season.isInauguralSeason
	},
	status: null,
	routeSegments,
	programs,
	faq,
	accommodations
};
/** Backend content wins whenever it has rows; static data is the safety net. */
function resolveContent(content) {
	if (!content) return fallback;
	return {
		season: content.season ?? fallback.season,
		status: content.status,
		routeSegments: content.routeSegments.length ? content.routeSegments : fallback.routeSegments,
		programs: content.programs.length ? content.programs : fallback.programs,
		faq: content.faq.length ? content.faq : fallback.faq,
		accommodations: content.accommodations.length ? content.accommodations : fallback.accommodations
	};
}
var ContentContext = (0, import_react.createContext)(fallback);
function SiteContentProvider({ value, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContentContext.Provider, {
		value,
		children
	});
}
function useSiteContent() {
	return (0, import_react.useContext)(ContentContext);
}
function Home() {
	const content = resolveContent(Route.useLoaderData());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteContentProvider, {
		value: content,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatIs, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OneWorld, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Journey, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Programming, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Highlights, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Havana, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HavanaGallery, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HavanaMap, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stay, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Practical, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tickets, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Location, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {})
		] })
	});
}
function Hero() {
	const { season } = useSiteContent();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative flex min-h-[92svh] items-end overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: hero_festi_ice_default,
				alt: "Patineurs sur un parcours de glace illuminé la nuit, entouré de structures lumineuses",
				width: 1920,
				height: 1088,
				className: "absolute inset-0 h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[var(--gradient-night)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-midnight/35" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto w-full max-w-7xl px-4 pb-16 pt-32 sm:px-6 lg:pb-24",
				children: [
					season.isInauguralSeason && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "eyebrow mb-4",
						children: ["Saison inaugurale · ", season.label]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.3em] text-silver",
						children: "Maricourt, Québec"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-4 text-[clamp(2.75rem,12vw,7.5rem)]",
						children: [
							"Patinez",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"dans la",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-ice",
								children: "lumière."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-lg text-base text-silver sm:text-lg",
						children: "Un parcours sur glace illuminé au cœur du Havana Resort, où musique, lumière et hiver se rencontrent."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/billets",
							className: "rounded-full bg-primary px-8 py-4 text-sm font-bold uppercase tracking-[0.18em] text-primary-foreground glow",
							children: "Billets"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#experience",
							className: "rounded-full border border-polar/40 px-8 py-4 text-sm font-bold uppercase tracking-[0.18em] text-foreground backdrop-blur-sm",
							children: "Découvrir l'expérience"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-10 flex flex-wrap gap-x-8 gap-y-3 text-xs font-semibold uppercase tracking-[0.16em] text-silver",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
									size: 14,
									className: "text-primary"
								}), " Havana Resort"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
									size: 14,
									className: "text-primary"
								}), " Expérience familiale"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music4, {
									size: 14,
									className: "text-primary"
								}), " Soirées musicales"]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
				className: "absolute bottom-5 left-1/2 hidden -translate-x-1/2 animate-bounce text-silver/70 lg:block",
				size: 22,
				"aria-hidden": true
			})
		]
	});
}
function WhatIs() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "experience",
		className: "scroll-mt-24 px-4 py-24 sm:px-6 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-12 lg:grid-cols-2 lg:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "L'expérience"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 text-[clamp(2rem,6vw,4rem)]",
					children: [
						"Une seule expérience.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-ice",
							children: "Jamais la même ambiance."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-xl text-base leading-relaxed text-muted-foreground",
					children: "À FESTI-ICE, on ne visite pas une série d'attractions séparées. On patine à travers le Havana Resort lui-même. De rue en rue, la lumière change, la musique change, l'atmosphère change — mais le parcours, lui, ne s'interrompt jamais."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 max-w-xl text-base leading-relaxed text-muted-foreground",
					children: [
						"Un domaine naturel de ",
						venue.acres,
						" acres devient, le temps d'une soirée d'hiver, un seul grand terrain de jeu illuminé."
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: ambiance_tunnel_default,
					alt: "Tunnel de lumières au-dessus d'un sentier glacé enneigé",
					loading: "lazy",
					width: 1200,
					height: 900,
					className: "w-full rounded-2xl object-cover shadow-[var(--glow-soft)]"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "shimmer-line pointer-events-none absolute inset-x-0 bottom-0 h-px" })]
			})]
		})
	});
}
function OneWorld() {
	const { routeSegments } = useSiteContent();
	const ref = (0, import_react.useRef)(null);
	const [active, setActive] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const nodes = ref.current?.querySelectorAll("[data-seg]");
		if (!nodes) return;
		const obs = new IntersectionObserver((entries) => {
			entries.forEach((e) => {
				if (e.isIntersecting) setActive(Number(e.target.getAttribute("data-seg")));
			});
		}, { rootMargin: "-45% 0px -45% 0px" });
		nodes.forEach((n) => obs.observe(n));
		return () => obs.disconnect();
	}, []);
	const seg = routeSegments[active] ?? routeSegments[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "parcours",
		ref,
		className: "scroll-mt-24 transition-colors duration-700",
		style: { backgroundColor: seg.background },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:py-32",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					style: { color: seg.accent },
					children: "Le parcours"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 text-[clamp(2rem,6vw,4rem)]",
					children: [
						"Un monde.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							style: { color: seg.accent },
							children: "Plusieurs ambiances."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: havanaPhotos.fleurs.url,
					alt: havanaPhotos.fleurs.altFr,
					width: havanaPhotos.fleurs.width,
					height: havanaPhotos.fleurs.height,
					loading: "lazy",
					decoding: "async",
					style: { objectPosition: havanaPhotos.fleurs.focal },
					className: "mt-10 aspect-[16/9] w-full rounded-2xl border border-border/40 object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-14 grid gap-12 lg:grid-cols-[1fr_1.1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:sticky lg:top-28 lg:h-fit",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "surface-frost rounded-2xl p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 200 320",
								className: "w-full",
								role: "img",
								"aria-label": "Tracé lumineux du parcours FESTI-ICE",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										d: "M30 300 C 20 240 70 230 60 180 C 52 138 130 140 128 100 C 126 62 80 60 100 20",
										fill: "none",
										stroke: "var(--border)",
										strokeWidth: "10",
										strokeLinecap: "round"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										d: "M30 300 C 20 240 70 230 60 180 C 52 138 130 140 128 100 C 126 62 80 60 100 20",
										fill: "none",
										stroke: seg.accent,
										strokeWidth: "3",
										strokeLinecap: "round",
										strokeDasharray: "1000",
										strokeDashoffset: 1e3 - (active + 1) / routeSegments.length * 1e3,
										style: { transition: "stroke-dashoffset 700ms ease, stroke 700ms ease" }
									}),
									routeSegments.map((s, i) => {
										const pts = [
											[30, 300],
											[58, 224],
											[58, 168],
											[112, 138],
											[128, 88],
											[100, 20]
										][i];
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: pts[0],
											cy: pts[1],
											r: i === active ? 7 : 4,
											fill: i <= active ? seg.accent : "var(--muted-foreground)",
											style: { transition: "all 500ms ease" }
										}, s.id);
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 border-t border-border/50 pt-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "eyebrow",
										style: { color: seg.accent },
										children: seg.street
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl",
										children: seg.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-xs text-muted-foreground",
										children: [
											seg.musicStyle,
											" · ",
											seg.lightingStyle
										]
									})
								]
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "space-y-6",
						children: routeSegments.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							"data-seg": i,
							className: `rounded-2xl border p-6 transition-all duration-500 ${i === active ? "border-transparent bg-card/80 shadow-[var(--glow-soft)]" : "border-border/40 bg-card/20 opacity-60"}`,
							style: i === active ? { borderColor: s.accent } : void 0,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground",
									children: [
										String(s.order).padStart(2, "0"),
										" · ",
										s.street
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 text-2xl",
									style: { color: i === active ? s.accent : void 0 },
									children: s.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted-foreground",
									children: s.descriptionFr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground",
									children: [
										s.musicStyle,
										" — ",
										s.lightingStyle
									]
								})
							]
						}, s.id))
					})]
				})
			]
		})
	});
}
function Journey() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-4 py-24 sm:px-6 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Le déroulement"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 max-w-2xl text-[clamp(2rem,6vw,3.5rem)]",
					children: [
						"De la voiture ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-ice",
							children: "à la glace"
						}),
						" en quelques minutes."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-12 grid gap-px overflow-hidden rounded-2xl border border-border/60 bg-border/60 sm:grid-cols-2 lg:grid-cols-3",
					children: [
						{
							t: "Arrivée",
							d: "Stationnement gratuit sur le domaine du Havana Resort."
						},
						{
							t: "Accueil",
							d: "Vous scannez votre billet QR à l'entrée de FESTI-ICE."
						},
						{
							t: "Préparation",
							d: "Zone d'enfilage des patins et aires chauffées."
						},
						{
							t: "Le parcours",
							d: "Vous entrez sur la glace et suivez les rues illuminées."
						},
						{
							t: "Les pauses",
							d: "Points de restauration, photos et arrêts en chemin."
						},
						{
							t: "Le retour",
							d: "Sortie près de l'accueil — et l'envie de revenir."
						}
					].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "bg-card p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-3xl text-ice",
								children: String(i + 1).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-lg",
								children: s.t
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: s.d
							})
						]
					}, s.t))
				})
			]
		})
	});
}
function Programming() {
	const { programs } = useSiteContent();
	const [selected, setSelected] = (0, import_react.useState)((programs[2] ?? programs[0]).dayIndex);
	const p = programs.find((x) => x.dayIndex === selected) ?? programs[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "programmation",
		className: "scroll-mt-24 border-y border-border/60 bg-card/30 px-4 py-24 sm:px-6 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Programmation"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 max-w-3xl text-[clamp(2rem,6vw,3.5rem)]",
					children: [
						"La glace est la même.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-ice",
							children: "La soirée, jamais."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-12 grid gap-8 lg:grid-cols-[300px_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 overflow-x-auto lg:flex-col lg:overflow-visible",
						children: programs.map((prog) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelected(prog.dayIndex),
							"aria-pressed": selected === prog.dayIndex,
							className: `shrink-0 rounded-xl border px-5 py-4 text-left transition-colors lg:w-full ${selected === prog.dayIndex ? "border-primary bg-primary/10" : "border-border/60 hover:border-primary/50"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground",
								children: prog.dayShortFr
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-sm font-semibold",
								children: prog.title
							})]
						}, prog.dayIndex))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "surface-frost rounded-2xl p-7 sm:p-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: p.dayLongFr
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-[clamp(2rem,7vw,3.5rem)] text-ice",
								children: p.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm font-semibold uppercase tracking-[0.16em] text-silver",
								children: p.styles
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-8 grid gap-6 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
										children: "Horaire"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
										className: "mt-1 font-semibold",
										children: [
											p.startTime,
											" – ",
											p.endTime
										]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
										children: "Public"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-semibold",
										children: p.recommendedAge
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
										children: "Disponibilité"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-semibold",
										children: p.status === "LOW_AVAILABILITY" ? "Peu de disponibilités" : p.status === "SOLD_OUT" ? "Complet" : "Billets disponibles"
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 text-sm text-muted-foreground",
								children: p.note
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/billets",
								search: { theme: p.title },
								className: "mt-8 inline-block rounded-full bg-primary px-8 py-4 text-xs font-bold uppercase tracking-[0.18em] text-primary-foreground",
								children: "Choisir cette soirée"
							})
						]
					})]
				})
			]
		})
	});
}
function Highlights() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-4 py-24 sm:px-6 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-12 lg:grid-cols-2 lg:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: ambiance_famille_default,
				alt: "Famille patinant sur un sentier illuminé bordé de sculptures lumineuses",
				loading: "lazy",
				width: 1200,
				height: 900,
				className: "w-full rounded-2xl object-cover shadow-[var(--glow-soft)]"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-8",
				children: [
					{
						icon: Sparkles,
						t: "Installations lumineuses grand format",
						d: "Des structures illuminées spectaculaires réparties le long du parcours."
					},
					{
						icon: Music4,
						t: "Une identité musicale par soirée",
						d: "Latin, pop, country, électro ou familial : la soirée change d'humeur."
					},
					{
						icon: Snowflake,
						t: "Le vrai hiver québécois",
						d: "Neige, forêt, air froid et lumière. Une expérience extérieure assumée."
					},
					{
						icon: Users,
						t: "Pensé pour les familles",
						d: "Enfants, ados, parents et grands-parents patinent sur le même parcours."
					}
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-11 w-11 shrink-0 place-items-center rounded-full border border-primary/40 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(i.icon, { size: 18 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg",
						children: i.t
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-sm text-muted-foreground",
						children: i.d
					})] })]
				}, i.t))
			})]
		})
	});
}
function Havana() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "havana",
		className: "scroll-mt-24 relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: havana_winter_default,
				alt: "Vue aérienne nocturne du domaine enneigé du Havana Resort",
				loading: "lazy",
				width: 1600,
				height: 1e3,
				className: "absolute inset-0 h-full w-full object-cover opacity-35"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-midnight/60" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-4 py-28 sm:px-6 lg:py-40",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Le lieu"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-4 text-[clamp(2.25rem,8vw,5rem)]",
						children: [
							venue.acres,
							" acres",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"à découvrir",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-ice",
								children: "sur glace."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-xl text-base text-silver",
						children: "FESTI-ICE prend vie au Havana Resort, un vaste domaine naturel de Maricourt dans les Cantons-de-l'Est."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-12 grid max-w-2xl gap-6 sm:grid-cols-3",
						children: venue.travelTimes.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "surface-frost rounded-xl p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
								children: t.from
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-display text-xl",
								children: t.minutes
							})]
						}, t.from))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs text-muted-foreground",
						children: "Les temps de déplacement sont approximatifs."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-14 grid items-center gap-8 rounded-2xl border border-border/50 bg-background/40 p-6 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: havanaPhotos.sign.url,
							alt: havanaPhotos.sign.altFr,
							width: havanaPhotos.sign.width,
							height: havanaPhotos.sign.height,
							loading: "lazy",
							decoding: "async",
							style: { objectPosition: havanaPhotos.sign.focal },
							className: "aspect-[4/3] w-full rounded-xl object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("address", {
							className: "not-italic",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "Adresse"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 font-display text-2xl",
									children: "Havana Resort"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm leading-relaxed text-silver",
									children: [
										"631, 7e Rang",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"Maricourt, QC",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"J0E 2L2"
									]
								})
							]
						})]
					})
				]
			})
		]
	});
}
function Stay() {
	const { accommodations } = useSiteContent();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-4 py-24 sm:px-6 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Hébergement"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 text-[clamp(2rem,6vw,3.5rem)]",
					children: [
						"Patinez.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-ice",
							children: "Restez dormir."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-xl text-sm text-muted-foreground",
					children: "Le Havana Resort dispose de son propre inventaire d'hébergement quatre-saisons sur le domaine. Les forfaits combinés avec FESTI-ICE ne sont pas encore en vente."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-12 grid gap-px overflow-hidden rounded-2xl border border-border/60 bg-border/60 sm:grid-cols-2 lg:grid-cols-5",
					children: accommodations.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "bg-card p-7 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-4xl text-ice",
							children: a.count
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs uppercase tracking-[0.14em] text-muted-foreground",
							children: a.label
						})]
					}, a.label))
				})
			]
		})
	});
}
function Practical() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "infos",
		className: "scroll-mt-24 border-y border-border/60 bg-card/30 px-4 py-24 sm:px-6 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Infos pratiques"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 text-[clamp(2rem,6vw,3.5rem)]",
					children: ["Tout ce qu'il faut ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-ice",
						children: "savoir."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "mt-12 grid gap-x-10 gap-y-6 sm:grid-cols-2 lg:grid-cols-4",
					children: practicalInfo.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-border/60 pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
							children: i.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1.5 text-sm font-semibold",
							children: i.value
						})]
					}, i.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-8 flex items-center gap-2 text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { size: 14 }), " La durée moyenne du parcours et les détails de location de patins seront confirmés avant l'ouverture."]
				})
			]
		})
	});
}
function Tickets() {
	const visible = ticketTypes.filter((t) => [
		"GENERAL",
		"SENIOR",
		"CHILD",
		"FAMILY",
		"TODDLER"
	].includes(t.code));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-4 py-24 sm:px-6 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Billets"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 text-[clamp(2rem,6vw,3.5rem)]",
					children: ["Des tarifs ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-ice",
						children: "clairs."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-5",
					children: visible.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-border/60 bg-card p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
								children: t.nameFr
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-display text-3xl text-ice",
								children: formatCents(t.priceCents)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs text-muted-foreground",
								children: t.descriptionFr
							})
						]
					}, t.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-muted-foreground",
					children: "Billet ouvert et tarif de groupe (15 personnes et plus) offerts à la billetterie. Taxes en sus, affichées avant le paiement."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/billets",
					className: "mt-8 inline-block rounded-full bg-primary px-10 py-4 text-sm font-bold uppercase tracking-[0.18em] text-primary-foreground glow",
					children: "Choisir mes billets"
				})
			]
		})
	});
}
function Location() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-border/60 px-4 py-24 sm:px-6 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 lg:grid-cols-2 lg:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Lieu"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-[clamp(2rem,6vw,3.5rem)]",
					children: "Havana Resort"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-5 text-base text-muted-foreground",
					children: [
						venue.address,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						venue.city,
						" ",
						venue.postalCode
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: venue.directionsUrl,
						target: "_blank",
						rel: "noreferrer",
						className: "rounded-full bg-primary px-8 py-4 text-xs font-bold uppercase tracking-[0.18em] text-primary-foreground",
						children: "Itinéraire"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#infos",
						className: "rounded-full border border-border px-8 py-4 text-xs font-bold uppercase tracking-[0.18em]",
						children: "Planifier ma visite"
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-frost rounded-2xl p-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Repères"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-3 text-sm text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stationnement gratuit sur le domaine" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Accès par le 7e Rang, à Maricourt" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Cantons-de-l'Est, Québec" })
					]
				})]
			})]
		})
	});
}
function Faq() {
	const { faq } = useSiteContent();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-border/60 bg-card/30 px-4 py-24 sm:px-6 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "FAQ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-4 text-[clamp(2rem,6vw,3.5rem)]",
					children: ["Avez-vous des ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-ice",
						children: "questions ?"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 space-y-10",
					children: faq.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm tracking-[0.2em] text-muted-foreground",
						children: group.group
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 divide-y divide-border/50 border-y border-border/50",
						children: group.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "group py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
								className: "flex cursor-pointer list-none items-center justify-between gap-4 text-sm font-semibold",
								children: [item.q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
									size: 16,
									className: "shrink-0 text-primary transition-transform group-open:rotate-180"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted-foreground",
								children: item.a
							})]
						}, item.q))
					})] }, group.group))
				})
			]
		})
	});
}
//#endregion
export { Home as component };
