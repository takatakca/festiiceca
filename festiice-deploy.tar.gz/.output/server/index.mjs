globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"2351-YF403/PNLgEb4zFGfq67soXEVQA\"",
		"mtime": "2026-09-07T18:16:53.672Z",
		"size": 9041,
		"path": "../public/favicon.png"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-07T18:16:53.672Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/billets-eVhLMxRq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3cf6-LTIluuPp1xmGmfOHQTJQa7lvTBk\"",
		"mtime": "2026-09-07T18:16:52.792Z",
		"size": 15606,
		"path": "../public/assets/billets-eVhLMxRq.js"
	},
	"/festi-ice-logo.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2b302-Q7la9hnnfYJKzI/rYi/H7DvCNCs\"",
		"mtime": "2026-09-07T18:16:53.674Z",
		"size": 176898,
		"path": "../public/festi-ice-logo.jpeg"
	},
	"/assets/ambiance-famille-D226qPNj.jpg": {
		"type": "image/jpeg",
		"etag": "\"2420f-zG/qB3mPV7juQFP82m1g7p68kTU\"",
		"mtime": "2026-09-07T18:16:52.793Z",
		"size": 147983,
		"path": "../public/assets/ambiance-famille-D226qPNj.jpg"
	},
	"/assets/ambiance-tunnel-Ujhg7UiV.jpg": {
		"type": "image/jpeg",
		"etag": "\"34159-uIe7mSPKQETAwNpDzq7j9s1q9pI\"",
		"mtime": "2026-09-07T18:16:52.794Z",
		"size": 213337,
		"path": "../public/assets/ambiance-tunnel-Ujhg7UiV.jpg"
	},
	"/assets/havana-la-playera-CW1LSjsB.jpeg": {
		"type": "image/jpeg",
		"etag": "\"53bf2-GeZIW82uqhauK7BS2ZL+Hzz0gfE\"",
		"mtime": "2026-09-07T18:16:52.795Z",
		"size": 343026,
		"path": "../public/assets/havana-la-playera-CW1LSjsB.jpeg"
	},
	"/assets/havana-mojito-bar-BCMVxMaT.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4564d-K+H4y8pQOQALNky2reO3Sh5rjxo\"",
		"mtime": "2026-09-07T18:16:52.795Z",
		"size": 284237,
		"path": "../public/assets/havana-mojito-bar-BCMVxMaT.jpeg"
	},
	"/assets/havana-fleurs-geantes-BoJlEgBn.jpeg": {
		"type": "image/jpeg",
		"etag": "\"54b3d-icVpBBrSlG0yvdmP2cFXdIKQryc\"",
		"mtime": "2026-09-07T18:16:52.794Z",
		"size": 346941,
		"path": "../public/assets/havana-fleurs-geantes-BoJlEgBn.jpeg"
	},
	"/assets/havana-rue-train-ACFF803R.jpeg": {
		"type": "image/jpeg",
		"etag": "\"4fb4d-c+dryj18Bx/DdKNIlRz8Q73EVcs\"",
		"mtime": "2026-09-07T18:16:52.796Z",
		"size": 326477,
		"path": "../public/assets/havana-rue-train-ACFF803R.jpeg"
	},
	"/assets/havana-winter-5DCWxEo1.jpg": {
		"type": "image/jpeg",
		"etag": "\"323b5-Aoik44c9gCJdor3jO1mr0hh41oU\"",
		"mtime": "2026-09-07T18:16:52.798Z",
		"size": 205749,
		"path": "../public/assets/havana-winter-5DCWxEo1.jpg"
	},
	"/assets/havana-train-DLAjZChj.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5898f-jtrzYdI46rCq36UPe+DuOPKkmc0\"",
		"mtime": "2026-09-07T18:16:52.798Z",
		"size": 362895,
		"path": "../public/assets/havana-train-DLAjZChj.jpeg"
	},
	"/assets/havana-carte-D1Y8f0RQ.jpeg": {
		"type": "image/jpeg",
		"etag": "\"5d24e-vVsB3HN2faaOVvBJFGPeFKFvqlk\"",
		"mtime": "2026-09-07T18:16:52.794Z",
		"size": 381518,
		"path": "../public/assets/havana-carte-D1Y8f0RQ.jpeg"
	},
	"/assets/jsx-runtime-BkSabwWG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c1-VkW1xFbt56H2FC99QIi6PTzaFIo\"",
		"mtime": "2026-09-07T18:16:52.792Z",
		"size": 961,
		"path": "../public/assets/jsx-runtime-BkSabwWG.js"
	},
	"/assets/havana-sign-DcZ3-eQF.jpeg": {
		"type": "image/jpeg",
		"etag": "\"57310-NHbCDybqDgS12qSdBbx4ASPkHzI\"",
		"mtime": "2026-09-07T18:16:52.797Z",
		"size": 357136,
		"path": "../public/assets/havana-sign-DcZ3-eQF.jpeg"
	},
	"/assets/plus-BgJ9hgTf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d7-F4qDr2EmpFneMsHtCxhIKv19K2s\"",
		"mtime": "2026-09-07T18:16:52.792Z",
		"size": 215,
		"path": "../public/assets/plus-BgJ9hgTf.js"
	},
	"/assets/routes-CZGydb54.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"166-YouHkF4YX9/O3SMx8YiLbDYK028\"",
		"mtime": "2026-09-07T18:16:52.793Z",
		"size": 358,
		"path": "../public/assets/routes-CZGydb54.js"
	},
	"/assets/routes-CQn_hfHp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"af99-Lo77GbKG3wUKK3tLlL2Nx8L6tSw\"",
		"mtime": "2026-09-07T18:16:52.793Z",
		"size": 44953,
		"path": "../public/assets/routes-CQn_hfHp.js"
	},
	"/assets/preload-helper-D5qHF3Yi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c167-vz0F8xmSRCsgVgPS5pRUP8n59f4\"",
		"mtime": "2026-09-07T18:16:52.792Z",
		"size": 49511,
		"path": "../public/assets/preload-helper-D5qHF3Yi.js"
	},
	"/assets/routes-CtKK4V-F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9baf-HRIDFvvuB65bBhWQN6DtSI2/oHU\"",
		"mtime": "2026-09-07T18:16:52.793Z",
		"size": 39855,
		"path": "../public/assets/routes-CtKK4V-F.js"
	},
	"/assets/routes-DPIkck-a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-lxflHNxrmO3/hq0KDUrc/v03eKg\"",
		"mtime": "2026-09-07T18:16:52.793Z",
		"size": 230,
		"path": "../public/assets/routes-DPIkck-a.js"
	},
	"/assets/styles-C5EIupVX.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1620b-f1Pm//fmMrSBy4cxFLKglpeHVHE\"",
		"mtime": "2026-09-07T18:16:52.799Z",
		"size": 90635,
		"path": "../public/assets/styles-C5EIupVX.css"
	},
	"/assets/hero-festi-ice-i7dSCSCs.jpg": {
		"type": "image/jpeg",
		"etag": "\"4f2a9-onuMv8/Ldu5KubLIKIuIIjMOyHk\"",
		"mtime": "2026-09-07T18:16:52.798Z",
		"size": 324265,
		"path": "../public/assets/hero-festi-ice-i7dSCSCs.jpg"
	},
	"/assets/index-BvtHJCd3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"786c3-5kDNzuLJY9XW2gGqPC3jltla5yI\"",
		"mtime": "2026-09-07T18:16:52.792Z",
		"size": 493251,
		"path": "../public/assets/index-BvtHJCd3.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_wNVgZN = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_wNVgZN
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
